
package com.example.order.saga;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.*;
import javax.persistence.*;
import java.util.*;

@RestController
@RequestMapping("/api/saga/orders")
public class SagaOrderCommandController {

    @Autowired
    private KafkaTemplate<String, Object> kafkaTemplate;

    @Autowired
    private OrderRepository orderRepository;

    @PostMapping
    public String createOrder(@RequestBody CreateOrderRequest request) {
        Order order = new Order(UUID.randomUUID().toString(), request.getCustomerId(), request.getItems(), "CREATED");
        orderRepository.save(order);

        OrderCreatedEvent event = new OrderCreatedEvent(order.getId(), order.getCustomerId(), order.getItems());
        kafkaTemplate.send("saga.order.created", event); // This triggers the saga orchestrator

        return order.getId();
    }
}

class CreateOrderRequest {
    private String customerId;
    private List<String> items;

    public String getCustomerId() { return customerId; }
    public void setCustomerId(String customerId) { this.customerId = customerId; }
    public List<String> getItems() { return items; }
    public void setItems(List<String> items) { this.items = items; }
}

@Entity
class Order {
    @Id
    private String id;
    private String customerId;
    private String status;

    @ElementCollection
    private List<String> items;

    public Order() {}

    public Order(String id, String customerId, List<String> items, String status) {
        this.id = id;
        this.customerId = customerId;
        this.items = items;
        this.status = status;
    }
}

class OrderCreatedEvent {
    private String orderId;
    private String customerId;
    private List<String> items;

    public OrderCreatedEvent(String orderId, String customerId, List<String> items) {
        this.orderId = orderId;
        this.customerId = customerId;
        this.items = items;
    }
}
